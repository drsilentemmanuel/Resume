const degrees = [
  {
    school: 'University of the People',
    degree: 'B.S Computer Science',
    link: 'https://www.uopeople.edu/',
    year: 2024,
  },
  {
    school: 'Code Space',
    degree: 'SOftware Development',
    link: 'https://www.codespace.co.za/',
    year: 2021,
  },
  {
    school: 'Amazon Web Services (AWS)',
    degree: 'AWS Certified Cloud Practitioner',
    link: 'https://aws.amazon.com/certification/exams/',
    year: 2021,
  },
  {
    school: 'Amazon Web Services (AWS)',
    degree: 'AWS Certified Solutions Architect Associate SAA-C02 [2022]',
    link: 'https://aws.amazon.com/certification/exams/',
    year: 2022,
  },
];

export default degrees;

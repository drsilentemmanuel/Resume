
# Intro

I am a detailed-oriented Full Stack Developer. I specialize in building beautiful, responsive and fast websites. Whether your needs lie in prototyping an idea fresh in your mind, setting up your e-commerce business or bringing out the big guns with Web development. I gurantee to bring an innovative solution to your brief. If you think I can be helpful to you or would like to meet me, please feel free to get in touch.

# Some history

- At 12, I was the best Mathematics Student, thanks to Mr Mundanga. 

- My brother put a computer in my bedroom when I was 14. It was an old Compaque Pentuim 3 that ran MS 98.

- The first software I installed was XP. 

- I started my first business when I was 16. I was unstoppable.

- I owned and ran a Video Club Business when I was 18. I was unstoppable.

- Early I started fixing computer hardware, installing software for friends, and just for fun as well.

- It took years for me to send my first email.

- At 22, I built my first website with Joomla. My website was terrible.

- At 26, I became a Global Shaper (World Economic Forum).

- As a self-taught developer, I had the chance to broaden my horizon by studying Computer Science at the University of People and Software development at CodeSpace.

- Dedicated to my late Brother, Stenford. Thank you for the Compaq PC 3 that sparked my fascination with computer programming and technology.


Ask me in person for other stories that I'm afraid to share with the internet.

# I like

- Art.
- Running.
- Travelling.
- Summer.
- Reading Books.
- Hiking.
- Teaching.

# Travel / Geography

- I am originally from Zimbabwe, Gweru. I have since lived in Cape Town, Durban, Johannesburg and Gaborone.
- I've hiked +50 mountains, some of which I have forgotten, and many of which I would like to revisit.
- I have traveled to 10 countries.
- After 2022, I hope to start traveling again.
- I first traveled solo when I was 13.
- My favorite country so far is United States of America.
- The most amazing place I have ever been is George, South Africa.

# Fun facts

- I don't use and have Whats App.
- I have never had more than 50 contacts on my phone.
- I am allergic to failure.
- I can't locate every country on a map.
- I added this page because so many people complained that my site was just my resume.
- I read the Bible everyday.

# I dream of

- always finding inspiration.
- enabling a brighter future.
- inspiring others.
- Building prayer mountains all over the world.

# My Role Models or people I admire

- Dr Strive Masiyiwa.
- Tyler Perry.
- Oprah Winfrey.
- Dr Chris Oyakhilome.
- H.E Uebert Angel.
- Elon Musk.
- Ye.

Of course, I am nowhere close to these people, yet. If you want to be on this list. Pester me and I might add you.

# Articles, Talks and Publications

- [Africa Is Geared Up](https://medium.com/@silentemmanuel/africa-is-geared-up-4b239daf95d1).
- [Can Artificial Intelligence help us tackle the pressing issues in Africa](https://medium.com/silent-dzikiti/can-artificial-intelligence-help-us-tackle-the-pressing-issues-in-africa-5eed3146eab)?
- [How machine learning and AI can help reduce the cyber- attacks](https://www.youtube.com/watch?v=Coj2ltDpi8Y).

# Cool Fact: 

- I vibe with the creator bigtime.
- The websites I have built process over USD$ 1 Million every year in transactions.

